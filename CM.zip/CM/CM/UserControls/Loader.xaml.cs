﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace CM.UserControls
{
    /// <summary>
    /// Interaction logic for Loader.xaml
    /// </summary>
    public partial class Loader : UserControl
    {
        const int ANIMATION_DURATION = 400;
        UIElement _parent;

        public Loader()
        {
            InitializeComponent();
            Visibility = Visibility.Hidden;
        }

        #region Message
        public string Message
        {
            //get { return (string)GetValue(MessageProperty); }
            //set { SetValue(MessageProperty, value); }
            get { return MessageTextBlock.Text; }
            set { MessageTextBlock.Text = value; }
        }

        // Using a DependecyProperty as the backing store for Message.
        // This enables for animation, styling, binding, etc...
        public static readonly DependencyProperty MessageProperty = DependencyProperty.Register("Message", typeof(string), typeof(Loader), new UIPropertyMetadata(string.Empty));
        #endregion

        double _min = 0;
        public double Minimum
        {
            get { return _min; }
            set { _min = value; }
        }

        double _max = 100;
        public double Maximum
        {
            get { return _max; }
            set { _max = value; }
        }

        double _value = 0;
        public double Value
        {
            get { return _value; }
            set
            {
                if (value < Minimum)
                    _value = Minimum;
                else if (value > Maximum)
                    _value = Maximum;
                else
                    _value = value;

                SetProgress(_value);
            }
        }

        void SetProgress(double value)
        {
            double newWidth;
            if (Minimum > Maximum)
                newWidth = brdProgressBar.Width;
            else if (Minimum == value)
                newWidth = 0;
            else
                newWidth = brdProgressBar.Width / ((Maximum - Minimum) / (value - Minimum));

            //if (newWidth < brdProgressBar.Width - 5)
            //    brdInnerProgress.CornerRadius = new CornerRadius(5, 0, 0, 5);
            //else
            //    brdInnerProgress.CornerRadius = new CornerRadius(5);
            if (newWidth == 0)
            {
                brdInnerProgress.Width = 0;
            }
            else
            {
                DoubleAnimation da = new DoubleAnimation(brdInnerProgress.Width, newWidth, new Duration(TimeSpan.FromMilliseconds(ANIMATION_DURATION)));
                brdInnerProgress.BeginAnimation(Border.WidthProperty, da);
            }
            //brdInnerProgress.Width = newWidth;
        }

        public void SetType(LoaderType type)
        {
            faIcon.Visibility = type == LoaderType.Indeterminate ? Visibility.Visible : Visibility.Collapsed;
            brdProgressBar.Visibility = type == LoaderType.ProgressBar ? Visibility.Visible : Visibility.Collapsed;
        }

        public void ShowHandlerDialog(LoaderType type = LoaderType.Indeterminate)
        {
            SetType(type);

            _parent = ((UIElement)this.Parent);
            _parent.IsEnabled = false;


            Visibility = Visibility.Visible;
        }

        public void HideHandlerDialog()
        {
            Visibility = Visibility.Hidden;
            _parent.IsEnabled = true;
        }
    }

    public enum LoaderType { Indeterminate, ProgressBar }
}
