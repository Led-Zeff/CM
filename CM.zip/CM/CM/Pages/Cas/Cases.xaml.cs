﻿using CM.Context;
using CM.Context.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CM.Utilities;
using System.Globalization;
using System.Data.Entity.SqlServer;
using System.Threading;
using CM.UserControls;

namespace CM.Pages.Cas
{
    /// <summary>
    /// Interaction logic for Cases.xaml
    /// </summary>
    public partial class Cases : Page
    {
        SearchTrigger<string> searcher;

        public Cases()
        {
            InitializeComponent();
            SetInitialValues();
        }

        void SetInitialValues()
        {
            LoadCases();
            //this.DataContext = this;
        }

        async Task LoadCases(string filter = null)
        {
            try
            {
                using (UnitOfWork unit = new UnitOfWork())
                using (new CursorOverrider())
                using (new LoaderHolder(loader))
                {
                    IQueryable<Context.Entities.Cas> query;

                    if (filter == null)
                    {
                        txtSearchCas.Text = string.Empty;
                        query = unit.CasRepository.Get();
                    }
                    else
                    {
                        DateTime date;
                        DateTime.TryParse(filter, CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal, out date);

                        query = unit.CasRepository.Get().Where(c =>
                                c.Number != null && c.Number.ToString().ToUpper().Contains(filter) ||
                                c.StartingDate != null && date == c.StartingDate ||
                                c.EndingDate != null && date == c.EndingDate ||
                                c.Project != null && c.Project.Name.ToUpper().Contains(filter)
                            );
                    }

                    dgCases.ItemsSource = await query.OrderByDescending(c => c.RegistrationDate).Select(
                        c => new { c.CasID, c.Number, c.StartingDate, c.EndingDate, ProjectName = c.Project.Name }
                        ).ToListAsync();
                }
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private async void btnAddCas_Click(object sender, RoutedEventArgs e)
        {
            await ShowCasDialog();
        }

        private async void btnCasDetails_Click(object sender, RoutedEventArgs e)
        {
            await ShowCasDialog((sender as Button).CommandParameter as int?);
        }

        async Task ShowCasDialog(int? casId = null)
        {
            bool? dialogResult = null;
            AddUpdCas casForm = new AddUpdCas();
            //casForm.Owner = Application.Current.MainWindow;
            if (casId == null)
            {
                dialogResult = casForm.ShowDialog();
            }
            else
            {
                dialogResult = await casForm.ShowDialog(casId);
            }
            if (bool.Equals(dialogResult, true))
            {
                await LoadCases();
            }
        }

        private void txtSearchCas_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (searcher == null)
                searcher = new SearchTrigger<string>(f =>
                    this.Dispatcher.Invoke(() => LoadCases(f))
                );
            searcher.SetFilter(string.IsNullOrWhiteSpace(txtSearchCas.Text) ? null : txtSearchCas.Text.Trim().ToUpper());
        }

        private async void btnDeleteCas_Click_1(object sender, RoutedEventArgs e)
        {
            NotificationResult qRes = Notificator.ShowMessage("Confirmar eliminación", "¿Eliminar CAS?", Application.Current.MainWindow, NotificationButtons.YesNo, FontAwesome.WPF.FontAwesomeIcon.QuestionCircle);
            if (qRes != NotificationResult.Yes) return;

            int? casId = (sender as Button).CommandParameter as int?;
            if (casId != null)
            {
                using (UnitOfWork unit = new UnitOfWork())
                {
                    unit.CasRepository.Delete(casId);
                    try
                    {
                        await unit.SaveAsync();
                        await LoadCases();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
    }
}
