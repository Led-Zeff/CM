﻿using CM.Context.Repositories;
using CM.Utilities;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CM.Pages.Project
{
    /// <summary>
    /// Interaction logic for AddUpdProject.xaml
    /// </summary>
    public partial class AddUpdProject : Window
    {
        Context.Entities.Project project;

        public AddUpdProject()
        {
            InitializeComponent();
            SetInitialData();
        }

        void SetInitialData()
        {
            tbTitle.Text = this.Title = "Agregar Sistema";

            project = new Context.Entities.Project();
            this.DataContext = project;
        }

        public async Task<bool?> ShowDialog(object id)
        {
            tbTitle.Text = this.Title = "Modificar Sistema";
            this.project = await GetProject(id);
            this.DataContext = project;

            return this.ShowDialog();
        }

        async Task<Context.Entities.Project> GetProject(object id)
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                return await unit.ProjectRepository.GetByIdAsync(id);
            }
        }

        private async void btnAddUpdProject_Click_1(object sender, RoutedEventArgs e)
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                if (project.ProjectID == 0)
                {
                    unit.ProjectRepository.Insert(project);
                }
                else
                {
                    unit.ProjectRepository.Update(project);
                }
                await unit.SaveAsync();
            }
            this.DialogResult = true;
            this.Close();
        }

        private void btnSelectLocalAppPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación de la Aplicación (local)", txtLocalAppPublishPath.Text, out newPath))
            {
                project.LocalAppPublishPath = newPath;
            }
        }

        private void btnSelectLocalFrontPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación del Front (local)", txtLocalFrontPublishPath.Text, out newPath))
            {
                project.LocalFrontPublishPath = newPath;
            }
        }

        private void btnSelectDevAppPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación de la Aplicación (desarrollo)", txtDevAppPublishPath.Text, out newPath, txtDevPathUser.Text, txtDevPathPassword.Text))
            {
                project.DevelopmentAppPublishPath = newPath;
            }
        }

        private void btnSelectDevFrontPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación del Front (Desarrollo)", txtDevFrontPublishPath.Text, out newPath, txtDevPathUser.Text, txtDevPathPassword.Text))
            {
                project.DevelopmentFrontPublishPath = newPath;
            }
        }

        private void OpenLocalAppPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtLocalAppPublishPath.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, this);
            }
        }

        private void OpenLocalFrontPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtLocalFrontPublishPath.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, this);
            }
        }

        private void OpenDevAppPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtDevAppPublishPath.Text, txtDevPathUser.Text, txtDevPathPassword.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, this);
            }
        }

        private void OpenDevFrontPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtDevFrontPublishPath.Text, txtDevPathUser.Text, txtDevPathPassword.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, this);
            }
        }

        private void OpenDevUrl(object sender, RoutedEventArgs e)
        {
            FileUtils.OpenResource(txtDevUrl.Text);
        }
    }
}
