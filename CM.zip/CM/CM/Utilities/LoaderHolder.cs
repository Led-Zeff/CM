﻿using CM.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace CM.Utilities
{
    class LoaderHolder : IDisposable
    {
        Loader loader;
        //System.Timers.Timer waiter;

        public LoaderHolder(Loader loader, string message = "Loading...")
        {
            this.loader = loader;
            loader.Message = message;

            //waiter = new System.Timers.Timer(500);
            //waiter.Elapsed += (_, __) => ShowLoader();
            //waiter.Start();
            loader.ShowHandlerDialog();
        }

        private void ShowLoader()
        {
            //waiter.Stop();
            loader.ShowHandlerDialog();
        }

        public void Dispose()
        {
            //waiter.Stop();
            //waiter.Dispose();
            loader.HideHandlerDialog();
        }

        void GetFocusedElement()
        {
            //UIElement parent = 
            //while()
        }
    }
}
