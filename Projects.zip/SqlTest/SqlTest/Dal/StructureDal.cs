﻿using SqlTest.Models;
using SqlTest.Src;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlTest.Dal {
    static class StructureDal {
        public static IEnumerable<MDatabase> GetDataBases(MConnection connection) {
            var task = Task<IEnumerable<MDatabase>>.Factory.StartNew(() =>
                SqlCommands.ExecuteCommand<MDatabase>(
                    connection.ConnectionString,
                    "SELECT name, suser_sname(owner_sid) [owner] FROM master.sys.databases",
                    reader => new MDatabase {
                        Name = reader.GetString(0),
                        Owner = reader.IsDBNull(1) ? null : reader.GetString(1),
                        Parent = connection,
                        Icon = @"Resources\database.png"
                    }
                )
            );
            task.Wait();
            return task.Result;
        }

        public static IEnumerable<MTable> GetTables(MDatabase database) {
            SqlParameter nameParam = new SqlParameter("@dbName", SqlDbType.VarChar);
            nameParam.Value = database.Name;

            var task = Task<IEnumerable<MTable>>.Factory.StartNew(() =>
                SqlCommands.ExecuteCommand<MTable>(
                    database.ConnectionString,
                    "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG = @dbName",
                    reader => new MTable {
                        Schema = reader.GetString(0),
                        Name = reader.GetString(1),
                        Parent = database,
                        Icon = @"Resources\table.png"
                    },
                    nameParam
                )
            );
            task.Wait();
            return task.Result;
        }

        public static IEnumerable<MColumn> GetColumns(MTable table) {
            MDatabase database = Utilities.GetParentOfType<MDatabase>(table);

            SqlParameter pDbName = new SqlParameter("@dbName", SqlDbType.VarChar);
            pDbName.Value = database.Name;
            SqlParameter pSchema = new SqlParameter("@schema", SqlDbType.VarChar);
            pSchema.Value = table.Schema;
            SqlParameter pTableName = new SqlParameter("@tblName", SqlDbType.VarChar);
            pTableName.Value = table.Name;

            var task = Task<IEnumerable<MColumn>>.Factory.StartNew(() =>
                SqlCommands.ExecuteCommand<MColumn>(
                    table.ConnectionString,
                    "select COLUMN_NAME, IS_NULLABLE, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, DATETIME_PRECISION " +
                            "from INFORMATION_SCHEMA.COLUMNS " +
                            "where TABLE_CATALOG = @dbName AND TABLE_SCHEMA = @schema AND TABLE_NAME = @tblName",
                    reader => new MColumn {
                        Name = reader.GetString(0),
                        IsNullable = reader.GetString(1) == "YES",
                        DataType = reader.GetString(2),
                        CharacterMaximumLength = reader.IsDBNull(3) ? null as int? : reader.GetInt32(3),
                        NumericPrecision = reader.IsDBNull(4) ? null as int? : reader.GetByte(4),
                        NumericScale = reader.IsDBNull(5) ? null as int? : reader.GetInt32(5),
                        DatetimePrecision = reader.IsDBNull(6) ? null as short? : reader.GetInt16(6),
                        Parent = table,
                        Icon = @"Resources\column_left.png"
                    },
                    pDbName, pSchema, pTableName 
                )
            );
            task.Wait();
            return task.Result;
        }
    }
}
