﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace SqlTest.Dal {
    class SqlCommands {
        public static IEnumerable<RT> ExecuteCommand<RT>(string connStr, string command, Func<SqlDataReader, RT> parser, params SqlParameter[] parameters) {
            using (SqlConnection sqlConnection = new SqlConnection(connStr)) {
                using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection)) {
                    foreach (var parameter in parameters) {
                        sqlCommand.Parameters.Add(parameter);
                    }
                    sqlConnection.Open();
                    var taskReader = sqlCommand.ExecuteReaderAsync();
                    taskReader.Wait();
                    while (taskReader.Result.Read()) {
                        yield return parser(taskReader.Result);
                    }
                }
            }
        }

        public static async Task<Tuple<DataSet, string[], string>> ExecuteCommand(string connStr, string command, params SqlParameter[] parameters) {
            using (SqlConnection sqlConnection = new SqlConnection(connStr)) {
                using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection)) {
                    foreach (var parameter in parameters) {
                        sqlCommand.Parameters.Add(parameter);
                    }
                    DataSet set = new DataSet();
                    await sqlConnection.OpenAsync();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand)) {
                        adapter.Fill(set);
                    }
                    return new Tuple<DataSet, string[], string>(set, null, null);
                }
            }
        }

        public static async Task<string> TestsConnection(string connStr)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connStr))
            {
                await sqlConnection.OpenAsync();
                return sqlConnection.Database;
            }
        }
    }
}
