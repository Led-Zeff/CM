﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace SqlTest.Src
{
    class Resources
    {
        static SettingsManager<Dictionary<string, string>> _builtInResources;
        static SettingsManager<Dictionary<string, string>> BuiltInResources
        {
            get
            {
                if (_builtInResources == null)
                {
                    string currDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                    _builtInResources = new SettingsManager<Dictionary<string, string>>(Path.Combine(currDir, Utilities.BUILT_IN_RESOURCES_PATH), SerializationMethod, DeserializationMethod);
                }
                return _builtInResources;
            }
        }

        Dictionary<string, string> _resources;
        Dictionary<string, string> EditorResources
        {
            get
            {
                if (_resources == null)
                    _resources = BuiltInResources.Load();
                return _resources;
            }
        }

        static void SerializationMethod(StreamWriter stream, object obj)
        {
            foreach (var item in obj as Dictionary<string, string>)
                stream.WriteLine(string.Format("{0}>{1}", item.Key, item.Value));
        }

        static Dictionary<string, string> DeserializationMethod(StreamReader stream)
        {
            Dictionary<string, string> resources = new Dictionary<string,string>();
            string line;
            string[] splitLine;
            while ((line = stream.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    splitLine = line.Split('>');
                    resources.Add(splitLine[0], splitLine.Length > 1 ? splitLine[1] : string.Empty);
                }
            }
            return resources;
        }

        public void AddResource(string key, string value)
        {
            EditorResources.Add(key, value);
        }

        public IEnumerable<KeyValuePair<string, string>> GetConincidences(string toSearch)
        {
            return EditorResources.Where(keyValue => keyValue.Key.IndexOf(toSearch, StringComparison.InvariantCultureIgnoreCase) > -1);
        }
    }
}
