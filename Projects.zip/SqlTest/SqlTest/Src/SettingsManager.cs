﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace SqlTest.Src {
    class SettingsManager<T> {
        public string FilePath { get; set; }
        Action<StreamWriter, object> actSerializer;
        Func<StreamReader, object> fnDeserializer;

        public SettingsManager(string filePath) {
            FilePath = filePath;
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            actSerializer = serializer.Serialize;
            fnDeserializer = serializer.Deserialize;
        }

        public SettingsManager(string filePath, Action<StreamWriter, object> serializer, Func<StreamReader, object> deserializer) {
            FilePath = filePath;
            actSerializer = serializer;
            fnDeserializer = deserializer;
        }

        public void Save(T obj) {
            using (StreamWriter writer = File.CreateText(FilePath)) {
                actSerializer(writer, obj);
            }
        }

        public T Load() {
            if (File.Exists(FilePath)) {
                using (StreamReader reader = File.OpenText(FilePath)) {
                    object data = fnDeserializer(reader);
                    return (T)data;
                }
            }
            return default(T);
        }
    }
}
