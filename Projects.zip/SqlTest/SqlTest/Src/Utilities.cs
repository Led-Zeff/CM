﻿using SqlTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Security.Principal;
using System.Windows.Input;

namespace SqlTest.Src {
    static class Utilities {
        public const string CONNECTION_SETTINGS_PATH = "settings";
        public const string BUILT_IN_RESOURCES_PATH = @"Resources\resources";
        public const string SYSTEM_DATABASES = "master|model|msdb|tempdb";
        public const string SQL_FIXED_SIZE_TYPES = "TEXT|NTEXT|IMAGE|BIT|TINYINT|SMALLINT|INT|BIGINT|REAL|SMALLMONEY|MONEY|DATE|DATETIME|SMALLDATETIME|TIME";

        public static MConnection Convertor(long key, string cStr) {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cStr);
            return new MConnection {
                Identifier = key,
                Server = builder.DataSource,
                User = string.IsNullOrEmpty(builder.UserID) ? WindowsIdentity.GetCurrent().Name : builder.UserID,
                ConnectionString = cStr,
                Icon = @"Resources\databases.png"
            };
        }

        public static IEnumerable<MConnection> Convertor(Dictionary<long, string> dict) {
            foreach (var item in dict) {
                yield return Convertor(item.Key, item.Value);
            }
        }

        //public static ConnectionItem Convertor(long key, string cStr) {
        //    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(cStr);
        //    return new ConnectionItem { Identifier = key, Type = ItemType.Connection, Header = string.Format("{0} ({1})", builder.DataSource, builder.UserID) };
        //}

        //public static IEnumerable<ConnectionItem> Convertor(Dictionary<long, string> dict) {
        //    foreach (var item in dict) {
        //        yield return Convertor(item.Key, item.Value);
        //    }
        //}

        public class OverrideCursor : IDisposable {
            public OverrideCursor(Cursor cursor) {
                Mouse.OverrideCursor = cursor;
            }

            public void Dispose() {
                Mouse.OverrideCursor = null;
            }
        }

        public static T GetParentOfType<T>(IItemView item) {
            if (item != null) {
                if (item is T)
                    return (T)item;
                else
                    return GetParentOfType<T>(item.Parent);
            }
            return default(T);
        }
    }
}
