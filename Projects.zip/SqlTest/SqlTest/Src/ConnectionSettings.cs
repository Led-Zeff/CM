﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows;

namespace SqlTest.Src {
    static class ConnectionSettings {
        private static SettingsManager<Dictionary<long, string>> _settingsMgn;
        private static SettingsManager<Dictionary<long, string>> SettingsMng {
            get {
                if (_settingsMgn == null){
                    string currDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                    _settingsMgn = new SettingsManager<Dictionary<long, string>>(Path.Combine(currDir, Utilities.CONNECTION_SETTINGS_PATH), SerializationMethod, DeserializationMethod);
                }
                return _settingsMgn;
            }
        }

        private static Dictionary<long, string> _connections;
        public static Dictionary<long, string> Connections {
            get {
                if (_connections == null)
                    _connections = SettingsMng.Load();
                if (_connections == null) {
                    _connections = new Dictionary<long, string>();
                }
                return _connections;
            }
            set {
                _connections = value;
            }
        }

        public static void Reload() {
            _connections = SettingsMng.Load();
        }

        public static void Save() {
            SettingsMng.Save(Connections);
        }

        private static void SerializationMethod(StreamWriter stream, object obj) {
            foreach (var item in obj as Dictionary<long, string>) {
                stream.WriteLine(item.Key + ":" + item.Value);
            }
        }

        private static Dictionary<long, string> DeserializationMethod(StreamReader stream) {
            Dictionary<long, string> dict = new Dictionary<long, string>();
            Regex rx = new Regex(@"^(\d+):(.+)$", RegexOptions.Compiled);
            Match match;
            string line;
            while ((line = stream.ReadLine()) != null) {
                match = rx.Match(line);
                if (match.Groups.Count == 3) {
                    dict.Add(long.Parse(match.Groups[1].Value), match.Groups[2].Value);
                }
            }
            return dict;
        }
    }
}
