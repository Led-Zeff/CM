﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SqlTest.Src
{
    class StringUtils
    {
        static Regex wordsRegex = new Regex(@"\w+", RegexOptions.Compiled);
        public static bool AreAllWords(string value)
        {
            return wordsRegex.IsMatch(value);
        }
    }
}
