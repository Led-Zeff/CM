﻿using SqlTest.Dal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlTest.Models {
    class MTable : IItemView {
        public IItemView Parent { get; set; }
        public bool AreChildrenLoaded { get; set; }
        public string ConnectionString { get { return Parent.ConnectionString; } set { Parent.ConnectionString = value; } }

        public string Schema { get; set; }
        public string Name { get; set; }
        public string Icon { get; set; }
        public string FullName { get { return string.Format("{0}.{1}", Schema, Name); } }
        public List<MColumn> Columns { get; set; }

        public IEnumerable<object> GetChildren() {
            if (!AreChildrenLoaded) {
                Columns = StructureDal.GetColumns(this).ToList();
            }
            return Columns;
        }
    }
}
