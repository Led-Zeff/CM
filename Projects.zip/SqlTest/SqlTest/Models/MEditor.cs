﻿using SqlTest.Dal;
using SqlTest.Src;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SqlTest.Models
{
    class MEditor : ANotify
    {
        public MDatabase Database { get; set; }

        string header;
        public string Header { get { return header; } set { SetValue(ref header, value); } }

        string query;
        public string Query { get { return query; } set { SetValue(ref query, value); } }

        string messages;
        public string Messages { get { return messages; } set { SetValue(ref messages, value); } }

        int currentIndex;
        public int CurrentIndex { get { return currentIndex; } set { SetValue(ref currentIndex, value); } }

        bool isPopupOpened;
        public bool IsPopupOpened { get { return isPopupOpened; } set { SetValue(ref isPopupOpened, value); } }

        string popupInformation;
        public string PopupInformation { get { return popupInformation; } set { SetValue(ref popupInformation, value); } }

        DataTable table;
        public DataTable Table
        {
            get { return Table; }
            set
            {
                table = value;
                NotifyPropertyChanged();
                NotifyPropertyChanged("QueryResultsView");
            }
        }

        Resources resources;
        public Resources Resources
        {
            get
            {
                if (resources == null)
                    resources = new Resources();
                return resources;
            }
        }

        public DataView QueryResultsView { get { return table != null ? table.DefaultView : null; } }

        bool expandedResults;
        public bool ExpandedResults { get { return expandedResults; } set { SetValue(ref expandedResults, value); } }

        public MEditor(IItemView connection, string header)
        {
            Header = header;
            MakeConnection(connection);
        }

        async Task MakeConnection(IItemView connection)
        {
            if (connection is MConnection)
            {
                string dbName = await SqlCommands.TestsConnection(connection.ConnectionString);
                UpdateDatabase(connection, dbName, false);
            }
            else
            {
                Database = Utilities.GetParentOfType<MDatabase>(connection);
            }
        }

        void UpdateDatabase(IItemView connection, string dbName, bool reloadDatabases)
        {
            if (Database != null && Database.Name == dbName) return;

            var conn = Utilities.GetParentOfType<MConnection>(connection);
            if (reloadDatabases)
                conn.AreChildrenLoaded = false;
            if (!conn.AreChildrenLoaded)
                conn.GetChildren();
            Database = conn.Databases.FirstOrDefault(db => db.Name == dbName);
        }

        public async Task ExecuteQuery() {
            if (string.IsNullOrWhiteSpace(Query)) return;
            try
            {
                DataSet set = (await SqlCommands.ExecuteCommand(Database.ConnectionString, Query)).Item1;
                if (set.Tables.Count > 0)
                {
                    Table = set.Tables[0];
                    CurrentIndex = 0;
                }
                else
                {
                    Messages = "";
                    currentIndex = 1;
                } 
            }
            catch (Exception ex)
            {
                Messages = ex.Message;
                CurrentIndex = 1;
            }
            ExpandedResults = true;
        }

        public void OnQueryKeyUp(object sender, KeyEventArgs e)
        {
            //IsPopupOpened = false;

            //if (e.KeyboardDevice.Modifiers != ModifierKeys.Control && e.KeyboardDevice.Modifiers != ModifierKeys.Alt && StringUtils.AreAllWords(e.Key.ToString()))
            //{
            //    PopupInformation = "Esttoooo";
            //    IsPopupOpened = true;
            //}
        }

        public void OnQueryTextChanged(object sender, TextChangedEventArgs e)
        {
            
        }
    }
}
