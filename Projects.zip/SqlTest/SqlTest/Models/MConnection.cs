﻿using SqlTest.Dal;
using SqlTest.Src;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SqlTest.Models {
    class MConnection : IItemView {
        public IItemView Parent { get; set; }
        public bool AreChildrenLoaded { get; set; }
        public string ConnectionString { get; set; }

        public long Identifier { get; set; }
        public string Server { get; set; }
        public string User { get; set; }
        public string Icon { get; set; }
        public List<MDatabase> Databases { get; set; }

        public IEnumerable<object> GetChildren() {
            if (!AreChildrenLoaded) {
                AreChildrenLoaded = true;
                try {
                    Databases = StructureDal.GetDataBases(this).ToList();
                } catch (Exception ex) {
                    Icon = "databases_exclamation.png";
                    throw ex;
                }
            }
            List<object> children = new List<object>();
            MDatabaseFolder systemDatabases = new MDatabaseFolder { Name = "System Databases", Icon = @"Resources\folder.png", Parent = this };
            children.Add(systemDatabases);
            if (Databases != null) {
                systemDatabases.Children = Databases.Where(db => Utilities.SYSTEM_DATABASES.Split('|').Contains(db.Name));
                children.AddRange(Databases.Where(db => !Utilities.SYSTEM_DATABASES.Split('|').Contains(db.Name)));
            }
            return children;
        }
    }
}
