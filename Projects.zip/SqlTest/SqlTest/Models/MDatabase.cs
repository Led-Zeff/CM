﻿using SqlTest.Dal;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SqlTest.Models
{
    class MDatabase : IItemView
    {
        public IItemView Parent { get; set; }
        public bool AreChildrenLoaded { get; set; }

        public string ConnectionString
        {
            get
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(Parent.ConnectionString);
                builder.InitialCatalog = Name;
                return builder.ConnectionString;
            }
            set { Parent.ConnectionString = value; }
        }

        public string Name { get; set; }
        public string Owner { get; set; }
        public string Icon { get; set; }
        public List<MTable> Tables { get; set; }

        public IEnumerable<object> GetChildren()
        {
            if (!AreChildrenLoaded)
            {
                AreChildrenLoaded = true;
                try
                {
                    Tables = StructureDal.GetTables(this).ToList();
                }
                catch (Exception ex)
                {
                    Icon = @"Resources\database_exclamation.png";
                    throw ex;
                }
            }
            return Tables;
        }
    }
}
