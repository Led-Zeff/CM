﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlTest.Models {
    interface IItemView {
        IItemView Parent { get; set; }
        bool AreChildrenLoaded { get; set; }
        string ConnectionString { get; set; }

        IEnumerable<object> GetChildren();
    }
}
