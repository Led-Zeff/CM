﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlTest.Models {
    class MFolder<ChildType> : IItemView where ChildType : class {
        public IItemView Parent { get; set; }
        public bool AreChildrenLoaded { get; set; }
        public string ConnectionString { get { return Parent.ConnectionString; } set { Parent.ConnectionString = value; } }

        public string Name { get; set; }
        public string Icon { get; set; }
        public IEnumerable<ChildType> Children { get; set; }

        public IEnumerable<object> GetChildren() {
            AreChildrenLoaded = true;
            return Children;
        }
    }
}
