﻿using SqlTest.Src;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlTest.Models {
    class MColumn : IItemView {
        public IItemView Parent { get; set; }
        public bool AreChildrenLoaded { get; set; }
        public string ConnectionString { get; set; }

        public string Name { get; set; }
        public bool IsNullable { get; set; }
        public string DataType { get; set; }
        public int? CharacterMaximumLength { get; set; }
        public int? NumericPrecision { get; set; }
        public int? NumericScale { get; set; }
        public short? DatetimePrecision { get; set; }
        public string Icon { get; set; }

        public string Detail {
            get {
                if (Utilities.SQL_FIXED_SIZE_TYPES.Split('|').Contains(DataType.ToUpper())) {
                    return string.Format("{0}, {1}", DataType, IsNullable ? "null" : "not null");
                } else {
                    return string.Format("{0}({1}), {2}",
                        DataType, 
                        CharacterMaximumLength != null ? CharacterMaximumLength == -1 ? "max" : CharacterMaximumLength.ToString() :
                        NumericPrecision != null ? NumericPrecision.ToString() + (NumericScale != null ? ", " + NumericScale.ToString() : "") :
                        DatetimePrecision.ToString(),
                        IsNullable ? "null" : "not null"
                    );
                }
            }
        }

        public IEnumerable<object> GetChildren() {
            return null;
        }
    }
}
