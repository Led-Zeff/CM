﻿using System.Windows;
using SqlTest.Src;
using System;
using System.Configuration;
using SqlTest.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using SqlTest.Dal;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.Data;

namespace SqlTest {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        ObservableCollection<MEditor> editors = new ObservableCollection<MEditor>();
        int editorsCount;

        public MainWindow() {
            InitializeComponent();

            SetInitialValues();
            LoadConnections();
            AddHandlers();
        }

        void SetInitialValues()
        {
            this.DataContext = this;
            tcEditors.ItemsSource = editors;
        }

        private void LoadConnections() {
            tvConnections.ItemsSource = Utilities.Convertor(ConnectionSettings.Connections);
        }

        private void AddQuery()
        {
            if (tvConnections.SelectedItem == null) return;

            editors.Add(new MEditor(tvConnections.SelectedItem as IItemView, string.Format("Query {0}.sql", ++editorsCount)));
            tcEditors.SelectedIndex = tcEditors.Items.Count - 1;
        }

        private void AddHandlers() {
            tvConnections.AddHandler(TreeViewItem.ExpandedEvent, new RoutedEventHandler(tvConnections_ItemExpanded));
        }

        private void imgAddConnection_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e) {
            ConnectionDialog dialog = new ConnectionDialog();
            dialog.Owner = this;
            long key;
            string str;
            if (dialog.ShowDialog(out str) ?? false) {
                key = DateTime.Now.Ticks;
                ConnectionSettings.Connections.Add(key, str);
                ConnectionSettings.Save();
                tvConnections.Items.Add(Utilities.Convertor(key, str));
            }
        }

        private void tvConnections_ItemExpanded(object sender, RoutedEventArgs e) {
            TreeViewItem item = e.OriginalSource as TreeViewItem;
            IItemView header = item.Header as IItemView;
            try {
                using (new Utilities.OverrideCursor(Cursors.Wait)) {
                    item.ItemsSource = header.GetChildren();
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void imgAddQuery_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e)
        {
            AddQuery();
        }

        private async void Window_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F5)
            {
                if (tcEditors.SelectedItem != null)
                {
                    MEditor editor = tcEditors.SelectedItem as MEditor;
                    await editor.ExecuteQuery();
                }
            }
        }

        private void txtQuery_MouseMove_1(object sender, MouseEventArgs e)
        {
            //if (!)
        }

        private void txtQuery_MouseLeave_1(object sender, MouseEventArgs e)
        {

        }

        private void txtQuery_KeyUp(object sender, KeyEventArgs e)
        {
            if ((sender as TextBox).DataContext is MEditor)
                ((sender as TextBox).DataContext as MEditor).OnQueryKeyUp(sender, e);
        }

        private void txtQuery_TextChanged(object sender, TextChangedEventArgs e)
        {
            if ((sender as TextBox).DataContext is MEditor)
                ((sender as TextBox).DataContext as MEditor).OnQueryTextChanged(sender, e);
        }
    }
}
