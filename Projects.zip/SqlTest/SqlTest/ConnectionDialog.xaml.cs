﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace SqlTest {
    /// <summary>
    /// Interaction logic for ConnectionDialog.xaml
    /// </summary>
    public partial class ConnectionDialog : Window {

        public ConnectionDialog() {
            InitializeComponent();
            ddlAuth.SelectedIndex = 1;
            txtServerName.Focus();
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e) {
            if (e.Key == Key.Escape) {
                this.DialogResult = false;
                this.Close();
            }
        }

        public bool? ShowDialog(out string connectionString) {
            connectionString = string.Empty;
            var res = this.ShowDialog();
            if (res ?? false) {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = txtServerName.Text;
                if (ddlAuth.SelectedIndex == 0) {
                    builder.IntegratedSecurity = true;
                } else {
                    builder.IntegratedSecurity = false;
                    builder.UserID = txtUserName.Text;
                    builder.Password = txtPassword.Text;
                    builder.PersistSecurityInfo = false;
                }
                
                connectionString = builder.ConnectionString;
            }
            return res;
        }

        private void btnConnect_Click_1(object sender, RoutedEventArgs e) {
            if (IsValidForm()) {
                this.DialogResult = true;
                this.Close();
            }
        }

        void ConnectionDialog_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e) {
            lblUserName.Visibility = lblPassword.Visibility = txtUserName.Visibility = txtPassword.Visibility = ddlAuth.SelectedIndex == 0 ? Visibility.Collapsed : Visibility.Visible;
        }

        private void Border_MouseDown_1(object sender, MouseButtonEventArgs e) {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private bool IsValidForm() {
            bool isInvalid;
            if (isInvalid = string.IsNullOrWhiteSpace(txtServerName.Text)) {
                txtServerName.Focus();
            } else if (isInvalid = ddlAuth.SelectedIndex == -1) {
                ddlAuth.Focus();
            } else if (isInvalid = ddlAuth.SelectedIndex == 1 && string.IsNullOrWhiteSpace(txtUserName.Text)) {
                txtUserName.Focus();
            } else if (isInvalid = ddlAuth.SelectedIndex == 1 && string.IsNullOrWhiteSpace(txtPassword.Text)) {
                txtPassword.Focus();
            }
            return !isInvalid;
        }
    }
}
