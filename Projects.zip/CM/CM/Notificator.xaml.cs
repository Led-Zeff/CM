﻿using FontAwesome.WPF;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace CM
{
    /// <summary>
    /// Interaction logic for Notifications.xaml
    /// </summary>
    public partial class Notificator : Window
    {
        NotificationResult result;

        Notificator(string title, string message, Window owner, Brush titleColor, Brush background, NotificationButtons? buttons = null, FontAwesomeIcon? icon = null)
        {
            InitializeComponent();

            this.Owner = owner;
            SetTexts(title, message);
            SetButtons(buttons);
            SetDefaultResult(buttons);
            SetIcon(icon);
            SetColors(titleColor, background);
        }

        void SetTexts(string title, string message)
        {
            tbTitle.Text = title;
            tbMessage.Text = message;
        }

        void SetButtons(NotificationButtons? buttons)
        {
            ugOKButtons.Visibility = buttons == NotificationButtons.OK ? Visibility.Visible : Visibility.Collapsed;
            ugOKCancelButtons.Visibility = buttons == NotificationButtons.OKCancel ? Visibility.Visible : Visibility.Collapsed;
            ugYesNoButons.Visibility = buttons == NotificationButtons.YesNo ? Visibility.Visible : Visibility.Collapsed;
            ugYesNoCancelButons.Visibility = buttons == NotificationButtons.YesNoCancel ? Visibility.Visible : Visibility.Collapsed;
        }

        void SetDefaultResult(NotificationButtons? buttons)
        {
            switch (buttons)
            {
                case NotificationButtons.OKCancel:
                case NotificationButtons.YesNoCancel:
                    result = NotificationResult.Cancel;
                    break;
                case NotificationButtons.YesNo:
                    result = NotificationResult.No;
                    break;
                default:
                    result = NotificationResult.OK;
                    break;
            }
        }

        void SetIcon(FontAwesomeIcon? icon)
        {
            if (icon == null)
            {
                messageIcon.Visibility = Visibility.Collapsed;
            }
            else
            {
                messageIcon.Icon = (FontAwesomeIcon)icon;
            }
        }

        void SetColors(Brush titleColor, Brush background)
        {
            brdTitle.Background = titleColor;
            Background = background;
        }

        void SetResult(object sender, RoutedEventArgs args)
        {
            result = (NotificationResult)int.Parse(((Button)sender).CommandParameter.ToString());
            Close();
        }

        private void brdTitle_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        public static NotificationResult ShowSuccess(string title, string message, Window owner, NotificationButtons? buttons = null, FontAwesomeIcon? icon = FontAwesomeIcon.CheckCircle)
        {
            var bc = new BrushConverter();
            var notif = new Notificator(title, message, owner, (Brush)bc.ConvertFrom("#FF389929"), (Brush)bc.ConvertFrom("#FF2AC14C"), buttons ?? NotificationButtons.OK, icon);
            notif.ShowDialog();
            return notif.result;
        }

        public static NotificationResult ShowMessage(string title, string message, Window owner, NotificationButtons? buttons = null, FontAwesomeIcon? icon = FontAwesomeIcon.InfoCircle)
        {
            var bc = new BrushConverter();
            var notif = new Notificator(title, message, owner, (Brush)bc.ConvertFrom("#FF3848AE"), (Brush)bc.ConvertFrom("#FF3845D1"), buttons ?? NotificationButtons.OK, icon);
            notif.ShowDialog();
            return notif.result;
        }

        public static NotificationResult ShowWarning(string title, string message, Window owner, NotificationButtons? buttons = null, FontAwesomeIcon? icon = FontAwesomeIcon.ExclamationCircle)
        {
            var bc = new BrushConverter();
            var notif = new Notificator(title, message, owner, (Brush)bc.ConvertFrom("#FFF09A1F"), (Brush)bc.ConvertFrom("#FFF79D52"), buttons ?? NotificationButtons.OK, icon);
            notif.ShowDialog();
            return notif.result;
        }

        public static NotificationResult ShowError(string title, string message, Window owner, NotificationButtons? buttons = null, FontAwesomeIcon? icon = FontAwesomeIcon.TimesCircle)
        {
            var bc = new BrushConverter();
            var notif = new Notificator(title, message, owner, (Brush)bc.ConvertFrom("#FFFD0000"), (Brush)bc.ConvertFrom("#FFFF4D44"), buttons ?? NotificationButtons.OK, icon);
            notif.ShowDialog();
            return notif.result;
        }
    }

    public enum NotificationButtons
    {
        OK, OKCancel, YesNo, YesNoCancel
    }

    public enum NotificationResult
    {
        OK, Cancel, Yes, No
    }
}
