﻿using CM.Context.Repositories;
using CM.Utilities;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CM.Pages.Project
{
    /// <summary>
    /// Interaction logic for AddUpdProject.xaml
    /// </summary>
    public partial class AddUpdProject : Page
    {
        Context.Entities.Project project;

        public event EventHandler ProjectAddedOrUpdated;

        public AddUpdProject(object projectId)
        {
            InitializeComponent();
            SetInitialData(projectId);
        }

        async Task SetInitialData(object projectId)
        {
            tbTitle.Text = this.Title = projectId == null ? "Agregar Sistema" : "Modificar Sistema";

            project = await GetProject(projectId);
            this.DataContext = project;
        }

        async Task<Context.Entities.Project> GetProject(object id)
        {
            if (id == null) return new Context.Entities.Project();

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                return await unit.ProjectRepository.GetByIdAsync(id) ?? new Context.Entities.Project();
            }
        }

        private async void btnAddUpdProject_Click_1(object sender, RoutedEventArgs e)
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                if (project.ProjectID == 0)
                {
                    unit.ProjectRepository.Insert(project);
                }
                else
                {
                    unit.ProjectRepository.Update(project);
                }
                await unit.SaveAsync();
            }
            if (ProjectAddedOrUpdated != null)
            {
                ProjectAddedOrUpdated.Invoke(this, new EventArgs());
            }
            NavigationService.GoBack();
        }

        private void btnSelectLocalAppPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación de la Aplicación (local)", txtLocalAppPublishPath.Text, out newPath))
            {
                project.LocalAppPublishPath = newPath;
            }
        }

        private void btnSelectLocalFrontPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación del Front (local)", txtLocalFrontPublishPath.Text, out newPath))
            {
                project.LocalFrontPublishPath = newPath;
            }
        }

        private void btnSelectDevAppPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación de la Aplicación (desarrollo)", txtDevAppPublishPath.Text, out newPath, txtDevPathUser.Text, txtDevPathPassword.Text))
            {
                project.DevelopmentAppPublishPath = newPath;
            }
        }

        private void btnSelectDevFrontPublishPath_Click_1(object sender, RoutedEventArgs e)
        {
            string newPath;
            if (FileUtils.ShowPickFolderDialog("Carpeta de publicación del Front (Desarrollo)", txtDevFrontPublishPath.Text, out newPath, txtDevPathUser.Text, txtDevPathPassword.Text))
            {
                project.DevelopmentFrontPublishPath = newPath;
            }
        }

        private void OpenLocalAppPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtLocalAppPublishPath.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private void OpenLocalFrontPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtLocalFrontPublishPath.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private void OpenDevAppPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtDevAppPublishPath.Text, txtDevPathUser.Text, txtDevPathPassword.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private void OpenDevFrontPublishPath(object sender, RoutedEventArgs e)
        {
            try
            {
                FileUtils.OpenFolderInExplorer(txtDevFrontPublishPath.Text, txtDevPathUser.Text, txtDevPathPassword.Text);
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private void OpenDevUrl(object sender, RoutedEventArgs e)
        {
            FileUtils.OpenResource(txtDevUrl.Text);
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
