﻿using CM.Context.Repositories;
using CM.Utilities;
using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace CM.Pages.Project
{
    /// <summary>
    /// Interaction logic for Projects.xaml
    /// </summary>
    public partial class Projects : Page
    {
        SearchTrigger<string> searcher;

        public Projects()
        {
            InitializeComponent();
            SetInitialData();
        }

        void SetInitialData()
        {
            LoadProjects();
        }

        async Task LoadProjects(string filter = null)
        {
            try
            {
                using (UnitOfWork unit = new UnitOfWork())
                using (new CursorOverrider())
                using (new LoaderHolder(loader))
                {
                    IQueryable<Context.Entities.Project> query;
                    if (filter == null)
                    {
                        txtSearch.Text = string.Empty;
                        query = unit.ProjectRepository.Get();
                    }
                    else
                    {
                        query = unit.ProjectRepository.Get().Where(p =>
                            p.Name != null && p.Name.ToUpper().Contains(filter.ToUpper()) ||
                            p.DevelopmentUrl != null && p.DevelopmentUrl.ToUpper().Contains(filter.ToUpper()) ||
                            p.DevelopmentAppPublishPath != null && p.DevelopmentAppPublishPath.ToUpper().Contains(filter.ToUpper()) ||
                            p.DevelopmentFrontPublishPath != null && p.DevelopmentFrontPublishPath.ToUpper().Contains(filter.ToUpper())
                        );
                    }
                    dgProjects.ItemsSource = await query.Select(
                        p => new { p.ProjectID, p.Name, p.DevelopmentUrl, p.DevelopmentAppPublishPath, p.DevelopmentFrontPublishPath }
                        ).ToListAsync();
                }
            }
            catch (Exception ex)
            {
                Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
            }
        }

        private void btnNewProject_Click_1(object sender, RoutedEventArgs e)
        {
            ShowProjectForm();
        }

        private void btnEditProject_Click_1(object sender, RoutedEventArgs e)
        {
            ShowProjectForm((sender as Button).CommandParameter as int?);
        }

        void ShowProjectForm(int? id = null)
        {
            AddUpdProject form = new AddUpdProject(id);
            form.ProjectAddedOrUpdated += async(_, __) => { await LoadProjects(); };
            NavigationService.Navigate(form);
        }

        private void txtSearch_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            if (searcher == null)
                searcher = new SearchTrigger<string>(f =>
                    this.Dispatcher.Invoke(() => LoadProjects(f))
                );
            searcher.SetFilter(string.IsNullOrWhiteSpace(txtSearch.Text) ? null : txtSearch.Text.Trim());
        }

        private async void btnDeleteProject_Click_1(object sender, RoutedEventArgs e)
        {
            NotificationResult qRes = Notificator.ShowMessage("Confirmar eliminación", "¿Eliminar el sistema?", Application.Current.MainWindow, NotificationButtons.YesNo, FontAwesome.WPF.FontAwesomeIcon.QuestionCircle);
            if (qRes != NotificationResult.Yes) return;

            int? projectId = (sender as Button).CommandParameter as int?;
            if (projectId != null)
            {
                using (UnitOfWork unit = new UnitOfWork())
                {
                    unit.ProjectRepository.Delete(projectId);
                    try
                    {
                        await unit.SaveAsync();
                        await LoadProjects();
                    }
                    catch (Exception ex)
                    {
                        Notificator.ShowError("Ocurrió un error", ex.Message, Application.Current.MainWindow);
                    }
                }
            }
        }
    }
}
