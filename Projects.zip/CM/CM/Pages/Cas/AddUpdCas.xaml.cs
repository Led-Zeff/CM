﻿using CM.Context.Entities;
using CM.Context.Repositories;
using CM.Pages.Project;
using CM.UserControls;
using CM.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CM.Pages.Cas
{
    /// <summary>
    /// Interaction logic for AddUpdCas.xaml
    /// </summary>
    public partial class AddUpdCas : Page
    {
        Context.Entities.Cas cas;
        
        public event EventHandler CasAddedOrUpdated;

        public AddUpdCas(object casId)
        {
            InitializeComponent();
            SetInitialValues(casId);
        }

        async Task SetInitialValues(object casId)
        {
            tbTitle.Text = this.Title = casId == null ? "Crear CAS" : "Modificar CAS";

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                ddlProject.ItemsSource = await unit.ProjectRepository.Get().ToListAsync();
            }

            cas = await GetCAS(casId);
            this.DataContext = cas;

            if (casId != null)
            {
                await LoadCasFilesApp();
                await LoadCasFilesFront();
            }
        }

        async Task LoadCasFilesApp()
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                dgPublishAppFiles.ItemsSource = await unit.CasFileRepository.Get().Where(c => c.CasId == cas.CasID && !c.IsDeleted && c.FileType == CasFileType.AppFile).OrderBy(c => c.RelativePath).Select(
                    c => new { c.CasFileID, c.RelativePath, HasOriginal = c.OriginalFile != null, HasModified = c.ModifiedFile != null }
                    ).ToListAsync();
            }
        }

        async Task LoadCasFilesFront()
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                dgPublishFrontFiles.ItemsSource = await unit.CasFileRepository.Get().Where(c => c.CasId == cas.CasID && !c.IsDeleted && c.FileType == CasFileType.FrontFile).OrderBy(c => c.RelativePath).Select(
                    c => new { c.CasFileID, c.RelativePath, HasOriginal = c.OriginalFile != null, HasModified = c.ModifiedFile != null }
                    ).ToListAsync();
            }
        }

        async Task<Context.Entities.Cas> GetCAS(object id)
        {
            if (id == null) return new Context.Entities.Cas();

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                return await unit.CasRepository.GetByIdAsync(id) ?? new Context.Entities.Cas();
            }
        }

        private async void btnSave_Click_1(object sender, RoutedEventArgs e)
        {
            await SaveCas();
            //DialogResult = true;
            //this.Close();
            //NavFrame.GoBack();
            NavigationService.GoBack();
        }

        async Task SaveCas()
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                if (cas.CasID == 0)
                {
                    unit.CasRepository.Insert(cas);
                }
                else
                {
                    unit.CasRepository.Update(cas);
                }
                await unit.SaveAsync();
                if (CasAddedOrUpdated != null)
                {
                    CasAddedOrUpdated.Invoke(this, new EventArgs());
                }
            }
        }

        private async void miDetectAppChanges_Click_1(object sender, RoutedEventArgs e)
        {
            int? projectId = ddlProject.SelectedValue as int?;
            if (projectId == null)
            {
                Notificator.ShowWarning("Campos necesarios", "Es necesario seleccionar un sistema", Application.Current.MainWindow);
                return;
            }
            if (dtpStartDate.SelectedDate == null)
            {
                Notificator.ShowWarning("Campos necesarios", "Es necesario seleccionar la fecha de inicio", Application.Current.MainWindow);
                return;
            }

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                var paths = await unit.ProjectRepository.Get().Where(p => p.ProjectID == projectId).Select(p =>
                        new { p.LocalAppPublishPath, p.DevelopmentAppPublishPath, p.DevPublishPathUser, p.DevPublishPathPassword }
                    ).SingleOrDefaultAsync();

                if (string.IsNullOrWhiteSpace(paths.LocalAppPublishPath) || string.IsNullOrWhiteSpace(paths.DevelopmentAppPublishPath))
                {
                    Notificator.ShowWarning("Datos faltantes", "El sistema seleccionado no tiene configuradas las rutas de publicación local o de desarrollo", Application.Current.MainWindow);
                    return;
                }

                if (await DetectAndInsertChanges(CasFileType.AppFile, paths.LocalAppPublishPath, paths.DevelopmentAppPublishPath, dtpStartDate.SelectedDate, paths.DevPublishPathUser, paths.DevPublishPathPassword) > 0)
                    await LoadCasFilesApp();
            }
        }

        private async void miDetectFrontChanges_Click_1(object sender, RoutedEventArgs e)
        {
            int? projectId = ddlProject.SelectedValue as int?;
            if (projectId == null)
            {
                Notificator.ShowWarning("Campos necesarios", "Es necesario seleccionar un sistema", Application.Current.MainWindow);
                return;
            }
            if (dtpStartDate.SelectedDate == null)
            {
                Notificator.ShowWarning("Campos necesarios", "Es necesario seleccionar la fecha de inicio", Application.Current.MainWindow);
                return;
            }

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                var paths = await unit.ProjectRepository.Get().Where(p => p.ProjectID == projectId).Select(p =>
                        new { p.LocalFrontPublishPath, p.DevelopmentFrontPublishPath, p.DevPublishPathUser, p.DevPublishPathPassword }
                    ).SingleOrDefaultAsync();

                if (string.IsNullOrWhiteSpace(paths.LocalFrontPublishPath) || string.IsNullOrWhiteSpace(paths.DevelopmentFrontPublishPath))
                {
                    Notificator.ShowWarning("Datos faltantes", "El sistema seleccionado no tiene configuradas las rutas de publicación local o de desarrollo", Application.Current.MainWindow);
                    return;
                }

                if (await DetectAndInsertChanges(CasFileType.FrontFile, paths.LocalFrontPublishPath, paths.DevelopmentFrontPublishPath, dtpStartDate.SelectedDate, paths.DevPublishPathUser, paths.DevPublishPathPassword) > 0)
                    await LoadCasFilesFront();
            }
        }

        private async Task<int> DetectAndInsertChanges(CasFileType fileType, string sourcePath, string targetPath, DateTime? startDate, string user, string password)
        {
            Stack<string> errorFiles = new Stack<string>();
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                if (cas.CasID == 0)
                {
                    await SaveCas();
                    await unit.SaveAsync();
                }
                byte[] fileBytes;
                string relativePath;
                foreach (var info in FileUtils.FindFiles(sourcePath, i => i.LastWriteTime >= startDate))
                {
                    relativePath = info.FullName.Replace(sourcePath.EndsWith(@"\") ? sourcePath : sourcePath + @"\", "");
                    if (!await unit.CasFileRepository.Get().AnyAsync(c => c.CasId == cas.CasID && c.RelativePath == relativePath && c.FileType == fileType))
                    {
                        fileBytes = null;
                        try
                        {
                            loader.Message = "Saving " + relativePath;
                            fileBytes = await Utilities.FileUtils.GetFileBytesAsync(System.IO.Path.Combine(targetPath, relativePath), user, password);
                        }
                        catch (Exception)
                        {
                            errorFiles.Push(System.IO.Path.Combine(targetPath, relativePath));
                        }
                        unit.CasFileRepository.Insert(new CasFile
                        {
                            CasId = cas.CasID,
                            FileType = fileType,
                            Name = info.Name,
                            RelativePath = relativePath,
                            OriginalFile = fileBytes
                        });
                    }
                }
                //if (errorFiles.Count > 0)
                //{
                //    string errors = "No se pudo tener acceso a los siguientes archivos:";
                //    while (errorFiles.Count > 0)
                //    {
                //        errors += "\n" + errorFiles.Pop();
                //    }
                //    MessageBox.Show(errors);
                //}
                return await unit.SaveAsync();
            }
        }

        private async void btnDeleteAppCasFile_Click_1(object sender, RoutedEventArgs e)
        {
            NotificationResult qRes = Notificator.ShowMessage("Confirmar eliminación", "¿Eliminar el archivo?, este archivo ya no se incluirá en la detección automática", Application.Current.MainWindow, NotificationButtons.YesNo, FontAwesome.WPF.FontAwesomeIcon.QuestionCircle);
            if (qRes == NotificationResult.Yes && await DeleteCasFile((sender as Button).CommandParameter as int?))
                await LoadCasFilesApp();
        }

        private async void btnDeleteFrontCasFile_Click_1(object sender, RoutedEventArgs e)
        {
            NotificationResult qRes = Notificator.ShowMessage("Confirmar eliminación", "¿Eliminar el archivo?, este archivo ya no se incluirá en la detección automática", Application.Current.MainWindow, NotificationButtons.YesNo, FontAwesome.WPF.FontAwesomeIcon.QuestionCircle);
            if (qRes == NotificationResult.Yes && await DeleteCasFile((sender as Button).CommandParameter as int?))
                await LoadCasFilesFront();
        }

        async Task<bool> DeleteCasFile(object casFileId)
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                CasFile file = await unit.CasFileRepository.GetByIdAsync(casFileId);
                if (file != null)
                {
                    file.IsDeleted = true;
                    file.OriginalFile = null;
                    file.ModifiedFile = null;
                    return await unit.SaveAsync() > 0;
                }
            }
            return false;
        }

        private async void miApplyAppChanges_Click_1(object sender, RoutedEventArgs e)
        {
            await ApplyChanges(CasFileType.AppFile);
        }

        private async void miRevertAppChanges_Click_1(object sender, RoutedEventArgs e)
        {
            await RevertChanges(CasFileType.AppFile);
        }

        private async void miApplyFrontChanges_Click_1(object sender, RoutedEventArgs e)
        {
            await ApplyChanges(CasFileType.FrontFile);
        }

        private async void miRevertFrontChanges_Click_1(object sender, RoutedEventArgs e)
        {
            await RevertChanges(CasFileType.FrontFile);
        }

        async Task ApplyChanges(CasFileType fileType)
        {
            Stack<string> errorFiles = new Stack<string>();
            byte[] localFileBytes;
            string originFilePath, targetFilePath;

            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                var files = await unit.CasFileRepository.Get().Where(cf => cf.CasId == cas.CasID && !cf.IsDeleted && cf.FileType == fileType).Select(
                        cf => new
                        {
                            CasFile = cf,
                            AppOriginPath = cf.Cas.Project.LocalAppPublishPath,
                            AppTargetPath = cf.Cas.Project.DevelopmentAppPublishPath,
                            FrontOriginPath = cf.Cas.Project.LocalFrontPublishPath,
                            FrontTargetPath = cf.Cas.Project.DevelopmentFrontPublishPath,
                            UserName = cf.Cas.Project.DevPublishPathUser,
                            Password = cf.Cas.Project.DevPublishPathPassword
                        }).ToListAsync();

                loader.Minimum = 0;
                loader.Maximum = files.Count;
                loader.Value = 0;
                loader.SetType(LoaderType.ProgressBar);

                foreach (var file in files)
                {
                    originFilePath = System.IO.Path.Combine((fileType == CasFileType.AppFile ? file.AppOriginPath : file.FrontOriginPath), file.CasFile.RelativePath);
                    targetFilePath = System.IO.Path.Combine((fileType == CasFileType.AppFile ? file.AppTargetPath : file.FrontTargetPath), file.CasFile.RelativePath);
                    try
                    {
                        loader.Message = "Copying " + file.CasFile.RelativePath;
                        localFileBytes = await FileUtils.GetFileBytesAsync(originFilePath);
                    }
                    catch (Exception)
                    {
                        errorFiles.Push(originFilePath);
                        continue;
                    }
                    try
                    {
                        FileUtils.DeleteFile(targetFilePath, file.UserName, file.Password);
                        await FileUtils.WriteAllBytesAsync(targetFilePath, localFileBytes, file.UserName, file.Password);
                    }
                    catch (Exception)
                    {
                        errorFiles.Push(targetFilePath);
                    }

                    file.CasFile.ModifiedFile = localFileBytes;
                    unit.CasFileRepository.Update(file.CasFile);
                    loader.Value++;
                }
                await unit.SaveAsync();
            }
            if (errorFiles.Count > 0)
            {
                string errorsMessage = "No se pudo tener acceso a los siguientes archivos:\n" + string.Join("\n", errorFiles);
                Notificator.ShowWarning("Error de acceso", errorsMessage, Application.Current.MainWindow);
            }
            else
            {
                Notificator.ShowSuccess("Cambios aplicados", "Se han copiado los archivos en el ambiente de desarrollo", Application.Current.MainWindow);
            }
        }

        async Task RevertChanges(CasFileType fileType)
        {
            using (UnitOfWork unit = new UnitOfWork())
            using (new CursorOverrider())
            using (new LoaderHolder(loader))
            {
                Stack<string> errorFiles = new Stack<string>();
                string targetPath;
                foreach (var file in await unit.CasFileRepository.Get().Where(cf => cf.CasId == cas.CasID && !cf.IsDeleted && cf.FileType == fileType).Select(
                        cf => new
                        {
                            RelativePath = cf.RelativePath,
                            OriginalFile = cf.OriginalFile,
                            AppTargetPath = cf.Cas.Project.DevelopmentAppPublishPath,
                            FrontTargetPath = cf.Cas.Project.DevelopmentFrontPublishPath,
                            UserName = cf.Cas.Project.DevPublishPathUser,
                            Password = cf.Cas.Project.DevPublishPathPassword
                        }).ToListAsync())
                {
                    targetPath = System.IO.Path.Combine((fileType == CasFileType.AppFile ? file.AppTargetPath : file.FrontTargetPath), file.RelativePath);
                    try
                    {
                        // Delete file and then, if the backup exists, restore it
                        loader.Message = "Deleting " + file.RelativePath;
                        FileUtils.DeleteFile(targetPath, file.UserName, file.Password);

                        if (file.OriginalFile != null)
                        {
                            loader.Message = "Restoring " + file.RelativePath;
                            await FileUtils.WriteAllBytesAsync(targetPath, file.OriginalFile, file.UserName, file.Password);
                        }
                    }
                    catch (Exception)
                    {
                        errorFiles.Push(targetPath);
                    }
                }
                if (errorFiles.Count > 0)
                {
                    string errorsMessage = "No se pudo tener acceso a los siguientes archivos:\n" + string.Join("\n", errorFiles);
                    Notificator.ShowWarning("Error de acceso", errorsMessage, Application.Current.MainWindow);
                }
            }
        }

        private async void btnLastPubAppFile_Click_1(object sender, RoutedEventArgs e)
        {
            int? id = (sender as Button).CommandParameter as int?;
            using (UnitOfWork unit = new UnitOfWork())
            {
                var file = await unit.CasFileRepository.dbSet.Where(cf => cf.CasFileID == id).Select(cf => new { cf.Name, cf.ModifiedFile }).FirstAsync();
                await FileUtils.SaveFile(file.Name, "Guardar último archivo publicado (App)", file.ModifiedFile);
            }
        }

        private async void btnOriginAppFile_Click_1(object sender, RoutedEventArgs e)
        {
            int? id = (sender as Button).CommandParameter as int?;
            using (UnitOfWork unit = new UnitOfWork())
            {
                var file = await unit.CasFileRepository.dbSet.Where(cf => cf.CasFileID == id).Select(cf => new { cf.Name, cf.OriginalFile }).FirstAsync();
                await FileUtils.SaveFile(file.Name, "Guardar archivo de respaldo (App)", file.OriginalFile);
            }
        }

        private async void btnLastPubFrontFile_Click_1(object sender, RoutedEventArgs e)
        {
            int? id = (sender as Button).CommandParameter as int?;
            using (UnitOfWork unit = new UnitOfWork())
            {
                var file = await unit.CasFileRepository.dbSet.Where(cf => cf.CasFileID == id).Select(cf => new { cf.Name, cf.ModifiedFile }).FirstAsync();
                await FileUtils.SaveFile(file.Name, "Guardar último archivo publicado (Front)", file.ModifiedFile);
            }
        }

        private async void btnOriginFrontFile_Click_1(object sender, RoutedEventArgs e)
        {
            int? id = (sender as Button).CommandParameter as int?;
            using (UnitOfWork unit = new UnitOfWork())
            {
                var file = await unit.CasFileRepository.dbSet.Where(cf => cf.CasFileID == id).Select(cf => new { cf.Name, cf.OriginalFile }).FirstAsync();
                await FileUtils.SaveFile(file.Name, "Guardar archivo de respaldo (Front)", file.OriginalFile);
            }
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F2)
            {
                int? id = ddlProject.SelectedValue as int?;
                if (id != null)
                {
                    var form = new AddUpdProject(id);
                    NavigationService.Navigate(form);
                }
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
