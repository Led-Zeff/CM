﻿using CM.Context.Entities;
using System.Windows;

namespace CM
{
    /// <summary>
    /// Interaction logic for Tests.xaml
    /// </summary>
    public partial class Tests : Window
    {
        static readonly DependencyProperty TBoxProperty = DependencyProperty.Register("TBox", typeof(string), typeof(Tests), new UIPropertyMetadata(string.Empty));
        string TBox
        {
            get { return (string)GetValue(TBoxProperty); }
            set { SetValue(TBoxProperty, value); }
        }

        static readonly DependencyProperty ProjectProperty = DependencyProperty.Register("Project", typeof(Project), typeof(Tests));
        Project Project
        {
            get { return (Project)GetValue(ProjectProperty); }
            set { SetValue(ProjectProperty, value); }
        }

        public Tests()
        {
            InitializeComponent();
            this.DataContext = this;
            Project = new Project();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            TBox = "yeeh";
        }
    }
}
